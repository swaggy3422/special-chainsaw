FUND.GO/EDD WEBSITE
-------------------
Files:
- index.html: the website
- catalog.js: 700 game-directory entries and 150 app/service links

Preview:
Open index.html in a modern browser. Keep catalog.js in the same folder.

Publish online:
1. Create a GitHub repository.
2. Upload index.html and catalog.js to the repository root.
3. In repository Settings > Pages, choose Deploy from a branch and select the main branch / root folder.
4. Save and wait for GitHub Pages to publish the site.
5. Use the generated pages.github.io address. A custom address such as fund.go/EDD requires ownership/control of that domain and DNS/hosting configuration.

Important:
- This is a static directory, not 700 original game builds. Game listings lead to established browser-game libraries.
- The app directory links to third-party services; availability, age limits and school access depend on those providers and local network policies.
- No proxy, stealth browsing, or school-filter bypass is included.
- Citation formatter formats details entered by the user; always verify citations against the original source and required style.
